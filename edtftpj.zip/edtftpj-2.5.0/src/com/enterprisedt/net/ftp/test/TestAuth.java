/**
 *
 *  Copyright (C) 2005  Enterprise Distributed Technologies Ltd
 *
 *  www.enterprisedt.com
 *
 *
 *  Change Log:
 *
 *        $Log: TestAuth.java,v $
 *        Revision 1.1  2015/05/05 08:15:16  bruceb
 *        wrong pwd test
 *
 *        Revision 1.4  2006/11/14 11:46:24  bruceb
 *        rename log
 *
 *        Revision 1.3  2006/07/27 13:45:29  bruceb
 *        ssh.com private key support
 *
 *        Revision 1.2  2005/11/10 19:49:32  bruceb
 *        added KBI
 *
 *        Revision 1.1  2005/10/15 22:43:53  bruceb
 *        auth testing
 *
 *        Revision 1.2  2005/10/10 20:51:34  hans
 *        Fixed up imports.
 *
 *        Revision 1.1  2005/08/13 08:29:44  bruceb
 *        CCC test
 *
 
 */
package com.enterprisedt.net.ftp.test;

import junit.framework.Test;
import junit.framework.TestSuite;
 
public class TestAuth extends FTPTestCase {

    /**
     * get name of log file
     * 
     * @return name of file to log to
     */
    protected String getLogName() {
        return "TestAuth.log";
    }

    /**
     * Test login
     */
	public void testWrongPassword() throws Exception {
        
        log.debug("testWrongPassword()");
        try {
            tools.setPassword("0f93$%rojw#2z");
            connect();
            fail();
        } 
        catch (Exception ex) {
            log.debug("connect failed as expected: " + ex.getMessage());
        }
        
        tools.setUser(tools.getWindowsUser());
        try {
            connect();
            fail();
        } 
        catch (Exception ex) {
            log.debug("connect failed as expected: " + ex.getMessage());
        }
	}
    
    
    /**
     *  Automatic test suite construction
     *
     *  @return  suite of tests for this class
     */
    public static Test suite() {
        return new TestSuite(TestAuth.class);
    } 

    /**
     *  Enable our class to be run, doing the
     *  tests
     */
    public static void main(String[] args) {       
        junit.textui.TestRunner.run(suite());
    }
}

